from setuptools import setup
setup(
    name='mipaquiete',
    version='1.0',
    description='una descripcion',
    author='la comi',
    packages=['paquete'],
)